import { Controller } from '@nestjs/common';

@Controller('notification-template')
export class NotificationTemplateController {}
