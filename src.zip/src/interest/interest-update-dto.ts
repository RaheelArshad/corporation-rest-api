import { ApiProperty } from "@nestjs/swagger";

export class InterestUpdateDto {
    @ApiProperty()
    name:string;
}
