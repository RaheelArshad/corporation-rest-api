import { ApiProperty } from "@nestjs/swagger";

export class InterestCreateDto {    
    @ApiProperty()
    name:string;
}
